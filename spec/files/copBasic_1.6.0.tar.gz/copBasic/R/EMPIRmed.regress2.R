"EMPIRmed.regress2" <-
function(...) {
   return(EMPIRqua.regress2(F=0.5, ...))
}

