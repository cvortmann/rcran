"EMPIRmed.regress" <-
function(...) {
   return(EMPIRqua.regress(F=0.5, ...))
}

