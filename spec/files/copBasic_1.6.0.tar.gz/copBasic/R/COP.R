"COP" <-
function(u, v, cop=NULL, para=NULL, ...) {
   #str(cop)
   return(cop(u,v, para=para, ...))
}
